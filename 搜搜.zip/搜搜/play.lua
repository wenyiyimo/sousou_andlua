require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"

import "android.graphics.*"
import "android.media.*"
import "java.lang.*"
import "android.content.DialogInterface"
import "android.graphics.drawable.BitmapDrawable"
import "android.graphics.PorterDuffColorFilter"
import "android.graphics.PorterDuff"
import "android.content.Context"
import "android.provider.Settings"
import "android.content.ContentResolver"
--Uri
import "android.net.Uri"
--exo

import "playout"
import "com.google.android.exoplayer2.C";
import "com.google.android.exoplayer2.MediaItem";
import "com.google.android.exoplayer2.Player";
import "com.google.android.exoplayer2.SimpleExoPlayer";
import "com.google.android.exoplayer2.drm.DefaultDrmSessionManager";
import "com.google.android.exoplayer2.drm.DrmSessionManager";
import "com.google.android.exoplayer2.drm.FrameworkMediaDrm";
import "com.google.android.exoplayer2.drm.HttpMediaDrmCallback";
import "com.google.android.exoplayer2.source.MediaSource";
import "com.google.android.exoplayer2.source.ProgressiveMediaSource";
import "com.google.android.exoplayer2.source.dash.DashMediaSource";
import "com.google.android.exoplayer2.source.hls.HlsMediaSource";
import "com.google.android.exoplayer2.ui.PlayerControlView";
import "com.google.android.exoplayer2.upstream.DataSource";
import "com.google.android.exoplayer2.upstream.DefaultDataSourceFactory";
import "com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory";
import "com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory";
import "com.google.android.exoplayer2.upstream.HttpDataSource";
import "com.google.android.exoplayer2.util.Assertions";
import "com.google.android.exoplayer2.util.Util";
import "com.google.android.exoplayer2.Player";
import "com.google.android.exoplayer2.PlaybackParameters"


activity.setContentView(loadlayout(playout))

sWidth=activity.getWidth()--获取屏幕宽
sHeight=activity.getHeight()--获取屏幕高
showcontrol=false
tcontrol.setVisibility(View.GONE)
bcontrol.setVisibility(View.GONE)
showspeed.setVisibility(View.GONE)
tefscreen.setVisibility(View.GONE)
rotate=0
fsflag=false
tcflag=false
voflag=false
bpflag=false
spflag=false
showspeedflag=false
nowplaynum=1
nowPosition=0
playspeed=1
sbright=100*(Settings.System.getInt(this.ContentResolver, Settings.System.SCREEN_BRIGHTNESS))/4095
playrate=1
--mediaPlayer = MediaPlayer()
--mediaPlayer=SimpleExoPlayer.Builder(this.getApplicationContext()).build();
ti=Ticker()
ti.Period=800
ti.onTick=function()
  --事件
  seekbar.setSecondaryProgress(mediaPlayer.getBufferedPosition())

  if mediaPlayer.isPlaying() then
    currentPosition=mediaPlayer.getCurrentPosition()
    seekbar.setProgress(currentPosition)
    nptimetext.setText(getplaytime(currentPosition))
    datetime.setText(os.date("%H:%M"))
    if currentPosition==nowPosition then
      mediaPlayer.seekTo(math.floor(currentPosition+1))

    end
    nowPosition=currentPosition
  end
end

surfaceView.setSurfaceTextureListener{
  onSurfaceTextureAvailable=function(v,w,h)

    mysurface=Surface(v)
  end,
  onSurfaceTextureDestroyed=function(v)
    mediaPlayer.release()
    ti.stop()
  end

}
--初始化参数



seekbar.ProgressDrawable.setColorFilter(PorterDuffColorFilter(0xffffffff,PorterDuff.Mode.SRC_ATOP))
seekbar.Thumb.setColorFilter(PorterDuffColorFilter(0xffffffff,PorterDuff.Mode.SRC_ATOP))
hrefurl,biaoti.Text,srcurl,zhuangtai.Text,laiyuan.Text,nowsite=...
goback.onClick=function()
  activity.finish()
end
function updatetag(num)
  for k,v in pairs(tags)
    --点击列表改变背景颜色。
    if k==num then

      v.tagname.textColor=0xFFFFFFFF
      v.tagname.backgroundColor=0xFF008AFF
     else
      v.tagname.textColor=0xFF000000
      v.tagname.backgroundColor=0x00FFFFFF
    end

  end
  adptags.notifyDataSetChanged()--更新列表
end

tagout= {
  LinearLayout;--线性布局
  orientation="horizontal";--布局方向
  layout_width="50dp";--布局宽度
  layout_height="30dp";--布局高度

  {
    CardView;
    background="#ffffff";
    layout_width="fill";--布局宽度
    layout_height="30dp";--布局高度
    {
      TextView;--水平分割线
      layout_width="fill";--布局宽度
      layout_height="fill";--布局高度
      paddingLeft="5dp";
      paddingRight="5dp";
      gravity="center|center";
      singleLine=true;
      id="tagname";
      textSize="20dp";
    };
  };

};
playout= {
  LinearLayout;--线性布局
  orientation="horizontal";--布局方向
  layout_width="20%w";--布局宽度
  layout_height="30dp";--布局高度

  {
    CardView;
    background="#ffffff";

    layout_width="fill";--布局宽度
    layout_height="30dp";--布局高度

    {
      TextView;--水平分割线
      layout_width="match_parent";--布局宽度
      layout_height="fill";--布局高度
      paddingLeft="5dp";
      paddingRight="5dp";
      gravity="center|center";
      singleLine=true;
      id="playname";
      textSize="16dp";
    };
    {
      TextView;--水平分割线
      layout_width="0dp";--布局宽度
      layout_height="0dp";--布局高度
      id="playhref";

    };
  };

};
tags={}
tagnum=1
alldatas={}
alldatas[1]={}
alldatas[2]={}
adptags=LuaAdapter(activity,tags,tagout)
taglist.setAdapter(adptags)

adptags.add({

  tagname={
    Text="逆序",
    backgroundColor=0x00FFFFFF,
    textColor=0xFF000000
  }
})
function getplaylist(num)
  playdatas={}
  adpplays=LuaAdapter(activity,playdatas,playout)
  playlist.setAdapter(adpplays)
  for k,v in pairs(alldatas[2][num]) do
    adpplays.add({

      playname={
        Text=string.sub(v[1],1,15),
        backgroundColor=0x00FFFFFF,
        textColor=0xFF000000
      },
      playhref={
        Text=v[2]
      }
    })


  end

end
Http.get(hrefurl,nil,"utf8",nil,function(a,b)

  if a==200 then

    tagrange=b:match(nowsite["play_tag_range"])

    tagrangelists=tagrange:gmatch(nowsite["play_tag_list"])

    for v in (tagrangelists) do
      title=string.gsub(v:match(nowsite["play_tag_name"]),"%s","")

      -- table.insert(alldatas[1],string.sub(title,1,6))
      table.insert(alldatas[1],title)
      adptags.add({

        tagname={Text=title,
          --  Text=string.sub(title,1,6),
          backgroundColor=0x00FFFFFF,
          textColor=0xFF000000
        }
      })

    end

    updatetag(2)
    playrange=b:match(nowsite["play_range"])

    playrangelists=playrange:gmatch(nowsite["play_list"])
    for pl in (playrangelists) do
      playitems=pl:gmatch(nowsite["play_item"])
      item={}
      for pi in (playitems) do
        temp={}
        temp[1]=string.gsub(pi:match(nowsite["play_name"]),"%s","")
        temp[2]=nowsite["url"]..pi:match(nowsite["play_href"])
        table.insert(item,temp)
        -- Toast.makeText(activity, tostring(phref),Toast.LENGTH_SHORT).show()
      end
      table.insert(alldatas[2],item)
      -- Toast.makeText(activity, tostring(playitems),Toast.LENGTH_SHORT).show()
    end
    getplaylist(1)

  end
end)
function getplaytime(time)
  tar=tointeger(time/1000)

  tarm=tointeger(tar/60)
  tars=tar%60
  if(tarm==0)then
    return "00:"..tostring(tars)
   else
    return tostring(tarm)..":"..tostring(tars)
  end

end
function sortplaylist()
  temp={}
  local num=#alldatas[2][tagnum]
  for k,v in pairs(alldatas[2][tagnum]) do

    temp[num-k+1]=v

  end
  alldatas[2][tagnum]=temp
  getplaylist(tagnum)
end
taglist.onItemClick=function(parent, v, pos,p)
  if p~=1 then

    updatetag(p)
    getplaylist(p-1)
    tagnum=(p-1)
   else
    sortplaylist()
  end
end
function updateplay(num)
  for k,v in pairs(playdatas)
    --点击列表改变背景颜色。
    if k==num then

      v.playname.textColor=0xFFFFFFFF
      v.playname.backgroundColor=0xFF008AFF
     else
      v.playname.textColor=0xFF000000
      v.playname.backgroundColor=0x00FFFFFF
    end

  end
  adpplays.notifyDataSetChanged()--更新列表
end



function getbili(sw,sh,pw,ph)

  if sw/pw<(sh/4)/ph then
    vbili=sw/pw
   else
    vbili=(sh/4)/ph
  end

  if sh/pw<sw/ph then
    hbili=sh/pw
   else
    hbili=sw/ph
  end

  return vbili,hbili
end


function changespeed(num)

  --[[local sparams = mediaPlayer.getPlaybackParams();
  sparams.setSpeed(tonumber(num));
  Toast.makeText(activity, tostring(sparams),Toast.LENGTH_SHORT).show()
  mediaPlayer.setPlaybackParams(sparams)--]]
  -- Toast.makeText(activity, tostring(3),Toast.LENGTH_SHORT).show()

  local sparams = PlaybackParameters(tonumber(num));
  mediaPlayer.setPlaybackParameters(sparams);

end

function setvideoparam(w,h,bili)
  sparam=surfaceView.getLayoutParams()
  sparam.width=w*bili
  sparam.height=h*bili
  surfaceView.setLayoutParams(sparam)
end
local context = this

local SURFACE_CONTROL_NAME = "surfacedemo";
local EXTENSION_EXTRA = "extension";
local DRM_SCHEME_EXTRA = "drm_scheme";
local DRM_LICENSE_URL_EXTRA = "drm_license_url";
local OWNER_EXTRA = "owner";
local intent = context.getIntent()

function initializePlayer(url)
  ---------以下代码看不懂 复制粘贴-----------
  local mediaSource = MediaSource
  local action = intent.getAction();

  local uri =Uri.parse(url);
  local type = Util.inferContentType(uri, intent.getStringExtra(EXTENSION_EXTRA));

  local drmSessionManager=DrmSessionManager
  if (intent.hasExtra(DRM_SCHEME_EXTRA))
    local drmScheme = Assertions.checkNotNull(intent.getStringExtra(DRM_SCHEME_EXTRA));
    local drmLicenseUrl = Assertions.checkNotNull(intent.getStringExtra(DRM_LICENSE_URL_EXTRA));
    local drmSchemeUuid = Assertions.checkNotNull(Util.getDrmUuid(drmScheme));
    local licenseDataSourceFactory = DefaultHttpDataSourceFactory();
    local drmCallback = HttpMediaDrmCallback(drmLicenseUrl, licenseDataSourceFactory);

    drmSessionManager = DefaultDrmSessionManager.Builder()
    .setUuidAndExoMediaDrmProvider(drmSchemeUuid, FrameworkMediaDrm.DEFAULT_PROVIDER)
    .build(drmCallback);
   else
    drmSessionManager = DrmSessionManager.DRM_UNSUPPORTED;
  end

  local dataSourceFactory = DefaultDataSourceFactory(context);

  if type == C.TYPE_DASH then
    mediaSource = DashMediaSource.Factory(dataSourceFactory)
    .setDrmSessionManager(drmSessionManager)
    .createMediaSource(MediaItem.fromUri(uri));
   elseif type == C.TYPE_OTHER then
    mediaSource = ProgressiveMediaSource.Factory(dataSourceFactory)
    .setDrmSessionManager(drmSessionManager)
    .createMediaSource(MediaItem.fromUri(uri));
   elseif type == C.TYPE_HLS then -- HLS (m3u8)
    mediaSource = HlsMediaSource.Factory(dataSourceFactory)
    .setDrmSessionManager(drmSessionManager)
    .createMediaSource(MediaItem.fromUri(uri));
  end

  mediaPlayer = SimpleExoPlayer.Builder(context.getApplicationContext()).build();
  -- mediaPlayer.setRepeatMode(Player.REPEAT_MODE_ONE);
  mediaPlayer.setMediaSource(mediaSource);
  mediaPlayer.prepare();
  --开始播放



  --开始播放
  mediaPlayer.play();
  clog.setVisibility(View.GONE)

  --启动Ticker定时器









  mediaPlayer.setVideoSurface(mysurface);

  ------------end--------------

  mediaPlayer.addListener(Player.EventListener{
    onTimelineChanged=function( timeline, manifest)
      --Timeline
    end,
    onTracksChanged=function( trackGroups, trackSelections)
      --Tracks
    end,
    onLoadingChanged=function(isLoading)
      -------加载 -无需设置

      -- Toast.makeText(activity, tostring(pt),Toast.LENGTH_SHORT).show()

    end,
    onPlayerStateChanged=function(playWhenReady, playbackState)
      switch (playbackState)
       case Player.STATE_ENDED
        --播放完了所有的资源后处于改状态
        if nowplaynum==#alldatas[2][tagnum] then
          Toast.makeText(activity, tostring("已经是最后一集"),Toast.LENGTH_SHORT).show()
         else
          nowplaynum=nowplaynum+1
          nowplaytime.setText(alldatas[2][tagnum][nowplaynum][1])


          updateplay(nowplaynum)

          getvideo(alldatas[2][tagnum][nowplaynum][2])


        end
       case Player.STATE_READY

        if playWhenReady then
          ti.start()

          seekbar.setMax(mediaPlayer.getContentDuration())
          aptime.setText(getplaytime(mediaPlayer.getContentDuration()))
          --获得视频宽高大小 并设置
          --->计算自适应大小
          pauseplay.setText("暂停")

          changespeed(playspeed)
          --Toast.makeText(activity, tostring(111),Toast.LENGTH_SHORT).show()

          tcontrol.setVisibility(View.VISIBLE)
          bcontrol.setVisibility(View.VISIBLE)

          showcontrol=true
          vWidth=mediaPlayer.getVideoSize().toBundle().getInt("0")
          vHeight=mediaPlayer.getVideoSize().toBundle().getInt("1")
          vbili,hbili=getbili(sWidth,sHeight,vWidth,vHeight)
          if fsflag==true then
            setvideoparam(vWidth,vHeight,hbili)
           else
            setvideoparam(vWidth,vHeight,vbili)
          end

        end

        --------播放器可以立即播放，是否播放取决于playWhenReady的值，该值表达了使用者的意愿，为true，将会开始播放，否则不播。
       case Player.STATE_BUFFERING


        --------没有足够的数据可以加载播放，此时无法立即播放
       case Player.STATE_IDLE
        --------初始状态，此时播放器没有可以播放的资源，播放器停止播放或者播放失败后也会处于该状态
      end
    end,
    onPlayerError=function(error)
      --播放出错 error.getMessage();
    end,
    onPositionDiscontinuity=function()
      --改变播放位置时触发
    end,
    onPlaybackParametersChanged=function(playbackParameters)
      --播放参数更改时触发
    end,
  });

end
function getvideo(playurl)
  if mediaPlayer~=nil then
    mediaPlayer.release();
    ti.stop()
  end

  clog.setVisibility(View.VISIBLE)
  clog.setText("正在嗅探视频中,请稍候...")
  --[=[ xt= ProgressDialog(this)
  xt.setProgressStyle(ProgressDialog.STYLE_SPINNER)
  --设置进度条的形式为圆形转动的进度条
  xt.setMessage([[正在嗅探视频中,请稍候...]])
  xt.setCancelable(true)--设置是否可以通过点击Back键取消
  xt.setCanceledOnTouchOutside(false)--设置在点击Dialog外是否取消Dialog进度条
  xt.show() --]=]
  webView2=LuaWebView(activity)
  --设置禁止自动播放视频
  webView2.getSettings().setMediaPlaybackRequiresUserGesture(true);
  webView2.loadUrl(playurl)
  webView2.setWebViewClient{
    onLoadResource=function(view,url)
      clog.setText("嗅探中:"..url)
      --xt.setMessage("嗅探中:"..url)
      if (url:find'mp4') or (url:find'm3u8') and (webView2.getUrl()~="about:blank") then
        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        -- Toast.makeText(activity, tostring(url),Toast.LENGTH_SHORT).show()
        webView2.stopLoading()
        --xt.setMessage("缓冲中...")
        clog.setText("缓冲中...")
        initializePlayer(url)

        return true;
      end

    end}
end



playlist.onItemClick=function(parent, v, pos,p)
  nowplaytime.setText(v.Tag.playname.Text)
  updateplay(p)
  nowplaynum=p
  getvideo(v.Tag.playhref.Text)

  --getvideo("https://saohuo.vip/play/43831-0-2.html")

end

fullscreen.onClick=function()
  activity.setRequestedOrientation(0);
  tefscreen.setVisibility(View.VISIBLE)
  fsflag=true
  activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
  activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)
  --sholder.setFixedSize(100%w, 100%h)
  --miniframe.removeView(surfaceView)
  fullscreen.setVisibility(View.GONE)
  header.setVisibility(View.GONE)
  efscreen.setVisibility(View.VISIBLE)
  param=frame.getLayoutParams()
  param.width=sHeight+50
  param.height=sWidth
  frame.setLayoutParams(param)
  sparam=surfaceView.getLayoutParams()
  sparam.width=vWidth*hbili
  sparam.height=vHeight*hbili
  surfaceView.setLayoutParams(sparam)



end

efscreen.onClick=function()
  fsflag=false
  rotateid()
  activity.setRequestedOrientation(1);
  header.setVisibility(View.VISIBLE)
  efscreen.setVisibility(View.GONE)
  fullscreen.setVisibility(View.VISIBLE)

  activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)

  param=frame.getLayoutParams()
  param.width=sWidth
  param.height=sHeight/4
  frame.setLayoutParams(param)
  sparam=surfaceView.getLayoutParams()
  sparam.width=vWidth*vbili
  sparam.height=vHeight*vbili
  surfaceView.setLayoutParams(sparam)


  sholder.setFixedSize(vWidth*vbili,vHeight*vbili)
  --sholder.setFixedSize(100%w, 100%h)
  --miniframe.removeView(surfaceView)

end

seekbar.setOnSeekBarChangeListener{
  onProgressChanged=function(a,i)
    nptimetext.setText(getplaytime(i))
    --ti.stop()
    --Toast.makeText(activity, tostring(i),Toast.LENGTH_SHORT).show()
  end,


  -- mediaPlayer.seekTo(math.floor(i))
  -- end
  onStopTrackingTouch=function(m)
    mediaPlayer.seekTo(math.floor(m.getProgress()))
    --ti.start()
  end
}


pauseplay.onClick=function()
  if (pauseplay.Text=="暂停") then
    mediaPlayer.pause()
    pauseplay.setText("开始")
   else
    mediaPlayer.play()
    pauseplay.setText("暂停")
  end
end
control.onLongClick=function()
  task(200,function()
    if tcflag==false then
      longclick=true
      changespeed(3)
      clog.setVisibility(View.VISIBLE)
      clog.setText("3倍速")

    end
  end)

end
function changebright(num)
  _window = activity.getWindow()

  wlp = _window.getAttributes()
  wlp.screenBrightness=num/100


  _window.setAttributes(wlp)

end
rotatevideo.onClick=function()
  if rotate==0 then
    rotate=180
    frame.setRotation(180)
    --control.setRotation()

   else
    rotate=0
    frame.setRotation(360)
    --control.setRotation(180)


  end
end
function controlevent()
  if fsflag==false then
    if rx<0.15*sWidth then
      -- Toast.makeText(activity, tostring(rotate),Toast.LENGTH_SHORT).show()


      bpflag=true
      nbright=sbright-dify/3
      if nbright<0 then
        nbright=0
       elseif nbright>100 then
        nbright=100
      end
      changebright(nbright)
      clog.setVisibility(View.VISIBLE)
      clog.setText("亮度:"..tostring(tointeger(sbright)).."/"..tostring(tointeger(nbright)))


     elseif rx>0.85*sWidth then

      voflag=true
      nvolume=rvolume-dify/3
      if nvolume<0 then
        nvolume=0
       elseif nvolume>100 then
        nvolume=100
      end
      setvolume(nvolume)
      clog.setVisibility(View.VISIBLE)
      clog.setText("音量:"..tostring(tointeger(rvolume)).."/"..tostring(tointeger(nvolume)))



     else
      spflag=true
      nptime=tointeger(difx*1000*0.25+rptime)
      if nptime<0 then
        nptime=0
       elseif nptime>mediaPlayer.getDuration() then
        nptime=mediaPlayer.getDuration()
      end

      clog.setVisibility(View.VISIBLE)
      if difx<0 then
        clog.setText("后退"..tostring(tointeger(-difx/4)).."秒")
       else
        clog.setText("快进"..tostring(tointeger(difx/4)).."秒")
      end
    end
   else
    if rx<0.2*sHeight then
      if rotate==0 then
        bpflag=true
        nbright=sbright-dify/3
        if nbright<0 then
          nbright=0
         elseif nbright>100 then
          nbright=100
        end
        changebright(nbright)
        clog.setVisibility(View.VISIBLE)
        clog.setText("亮度:"..tostring(tointeger(sbright)).."/"..tostring(tointeger(nbright)))
       else
        voflag=true
        nvolume=rvolume+dify/3
        if nvolume<0 then
          nvolume=0
         elseif nvolume>100 then
          nvolume=100
        end
        setvolume(nvolume)
        clog.setVisibility(View.VISIBLE)
        clog.setText("音量:"..tostring(tointeger(rvolume)).."/"..tostring(tointeger(nvolume)))

      end
     elseif rx>0.9*sHeight then
      if rotate==0 then
        voflag=true
        nvolume=rvolume-dify/3
        if nvolume<0 then
          nvolume=0
         elseif nvolume>100 then
          nvolume=100
        end
        setvolume(nvolume)
        clog.setVisibility(View.VISIBLE)
        clog.setText("音量:"..tostring(tointeger(rvolume)).."/"..tostring(tointeger(nvolume)))
       else
        bpflag=true
        nbright=sbright+dify/3
        if nbright<0 then
          nbright=0
         elseif nbright>100 then
          nbright=100
        end
        changebright(nbright)
        clog.setVisibility(View.VISIBLE)
        clog.setText("亮度:"..tostring(tointeger(sbright)).."/"..tostring(tointeger(nbright)))

      end
     else
      if rotate==0 then
        spflag=true

        nptime=tointeger(difx*1000*0.1+rptime)
        if nptime<0 then
          nptime=0
         elseif nptime>mediaPlayer.getDuration() then
          nptime=mediaPlayer.getDuration()
        end

        clog.setVisibility(View.VISIBLE)
        if difx<0 then
          clog.setText("后退"..tostring(tointeger(-difx/10)).."秒")
         else
          clog.setText("快进"..tostring(tointeger(difx/10)).."秒")
        end
       else
        spflag=true

        nptime=tointeger(-difx*1000*0.1+rptime)
        if nptime<0 then
          nptime=0
         elseif nptime>mediaPlayer.getDuration() then
          nptime=mediaPlayer.getDuration()
        end

        clog.setVisibility(View.VISIBLE)
        if difx<0 then
          clog.setText("快进"..tostring(tointeger(-difx/10)).."秒")
         else
          clog.setText("后退"..tostring(tointeger(difx/10)).."秒")
        end
      end
    end
  end
end
--control.setLongClickable(true)
countnum=0

control.onTouch=function(v,e)

  -- starttime=System.currentTimeMillis()
  -- Toast.makeText(activity, tostring(e.getAction()),Toast.LENGTH_SHORT).show()
  if e.getAction() == MotionEvent.ACTION_DOWN then
    starttime=System.currentTimeMillis()
    ry=e.getRawY()--获取触摸绝对Y位置
    rx=e.getRawX()
    rvolume=getvolume()
    rptime=mediaPlayer.getCurrentPosition()
   elseif e.getAction() == MotionEvent.ACTION_MOVE then
    ny=tointeger(e.getRawY())
    nx=tointeger(e.getRawX())
    difx=nx-rx
    dify=ny-ry
    diftime=System.currentTimeMillis()-starttime
    -- Toast.makeText(activity, tostring(nx),Toast.LENGTH_SHORT).show()
    if diftime<500 then
      if dify>2 or difx>2 or difx<-2 or dify<-2 then
        tcflag=true
        controlevent()
      end
     else
      if tcflag==true then
        controlevent()
      end

    end

   elseif e.getAction() == MotionEvent.ACTION_UP then
    countnum=countnum+1
    --local nowtime=System.currentTimeMillis()
    --local diftime=nowtime-starttime
    task(200,function()
      if countnum==1 then
        countnum=0
        if tcflag==false then
          if longclick==false then
            shcontrol()
           else
            longclick=false
            changespeed(playspeed)
            clog.setVisibility(View.GONE)
          end
         else
          tcflag=false
          clog.setVisibility(View.GONE)
          if spflag==true then
            spflag=false

            nptimetext.setText(getplaytime(nptime))
            mediaPlayer.seekTo(nptime)
            seekbar.setProgress(nptime)

          end
          if voflag==true then
            voflag=false
            setvolume(nvolume)
          end
          if bpflag==true then
            bpflag=false
            changebright(nbright)
            nbright=sbright
          end

        end

       elseif countnum==2 then
        countnum=0
        if (pauseplay.Text=="暂停") then
          mediaPlayer.pause()
          pauseplay.setText("开始")
         else
          mediaPlayer.play()
          pauseplay.setText("暂停")
        end
      end
      clog.setVisibility(View.GONE)
    end)


    --starttime=nowtime
  end
end


--显示或隐藏控件
function shcontrol()
  if(showcontrol==false) then
    tcontrol.setVisibility(View.VISIBLE)
    bcontrol.setVisibility(View.VISIBLE)
    showcontrol=true
   else
    tcontrol.setVisibility(View.GONE)
    bcontrol.setVisibility(View.GONE)
    showcontrol=false
  end
end

mAudioManager=activity.getSystemService(Context.AUDIO_SERVICE);
function getvolume()
  return mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

end

function setvolume(num)
  mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC,num,0)
end


function rotateid()
  if rotate==180 then

    frame.setRotation(360)
    rotate=0

  end
end



nextplay.onClick=function
  if nowplaynum==#alldatas[2][tagnum] then
    Toast.makeText(activity, tostring("已经是最后一集"),Toast.LENGTH_SHORT).show()
   else
    nowplaynum=nowplaynum+1
    nowplaytime.setText(alldatas[2][tagnum][nowplaynum][1])


    updateplay(nowplaynum)

    getvideo(alldatas[2][tagnum][nowplaynum][2])


  end
end

lastplay.onClick=function()
  if nowplaynum==1 then
    Toast.makeText(activity, tostring("已经是第一集"),Toast.LENGTH_SHORT).show()
   else
    nowplaynum=nowplaynum-1
    nowplaytime.setText(alldatas[2][tagnum][nowplaynum][1])


    updateplay(nowplaynum)

    getvideo(alldatas[2][tagnum][nowplaynum][2])

  end

end




setspeed.onClick=function()
  if showspeedflag==false then
    showspeed.setVisibility(View.VISIBLE)
    showspeedflag=true
   else
    showspeedflag=false
    showspeed.setVisibility(View.GONE)
  end
end

一零.onClick=function()

  changespeed(1.0)
  setspeed.setText("倍速:1.0")
  playspeed=1.0
end
一二五.onClick=function()
  changespeed(1.25)
  setspeed.setText("倍速:1.25")
  playspeed=1.25
end
一五.onClick=function()

  changespeed(1.5)
  setspeed.setText("倍速:1.5")
  playspeed=1.5
end
一七五.onClick=function()

  changespeed(1.75)
  setspeed.setText("倍速:1.75")
  playspeed=1.75
end
二零.onClick=function()
  changespeed(2.0)
  setspeed.setText("倍速:2.0")
  playspeed=2.0

end
三零.onClick=function()

  changespeed(3.0)
  setspeed.setText("倍速:3.0")
  playspeed=3.0
end
四零.onClick=function()

  changespeed(4.0)
  setspeed.setText("倍速:4.0")
  playspeed=4.0
end
五零.onClick=function()
  playspeed=5.0
  changespeed(5.0)
  setspeed.setText("倍速:5.0")
end


tefscreen.onClick=function()
  if(fsflag==true) then
    tefscreen.setVisibility(View.GONE)
    fsflag=false
    rotateid()
    activity.setRequestedOrientation(1);
    header.setVisibility(View.VISIBLE)
    efscreen.setVisibility(View.GONE)
    fullscreen.setVisibility(View.VISIBLE)

    activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)

    param=frame.getLayoutParams()
    param.width=sWidth
    param.height=sHeight/4
    frame.setLayoutParams(param)
    sparam=surfaceView.getLayoutParams()
    sparam.width=vWidth*vbili
    sparam.height=vHeight*vbili
    surfaceView.setLayoutParams(sparam)


    sholder.setFixedSize(vWidth*vbili,vHeight*vbili)
  end
end

