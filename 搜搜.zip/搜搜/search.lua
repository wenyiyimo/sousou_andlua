require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "searchout"
import "cjson"

activity.setContentView(loadlayout(searchout))
searchword=...

searchtext.Text=searchword
--Toast.makeText(activity,searchword, Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
jsondata = cjson.decode(io.open("sdcard/搜搜/site.json"):read("*a"))

goback.onClick=function()
  activity.finish()
end
searchitem={
  LinearLayout;
  layout_height="wrap";
  background="#00FFFFFF";
  layout_width="fill";
  orientation="vertical";
  {
    CardView;--卡片控件
    layout_margin='8dp';--边距
    layout_gravity='center';--重力
    --左:left 右:right 中:center 顶:top 底:bottom
    elevation='5dp';--阴影
    layout_width='fill';--宽度
    layout_height='wrap';--高度
    CardBackgroundColor='#ffffffff';--颜色
    radius='8dp';--圆角
    {
      LinearLayout;--帧布局
      orientation="horizontal";--方向
      layout_width='fill';--宽度
      layout_height='wrap';--高度
      background='#00FFFFFF';--背景颜色或图片路径
      {
        ImageView;--图片控件
        src='';--图片路径
        layout_width='18%w';--宽度
        layout_height='24%w';--高度
        scaleType='fitXY';--图片显示类型
        id="tupian";

      };
      {
        LinearLayout,--线性布局
        orientation='vertical',--方向
        layout_width='wrap',--宽度
        layout_height='24%w',--高度
        background='#00FFFFFF',--背景颜色或图片路径
        layout_marginLeft="10dp";
        {
          TextView;--文本控件
          --左:left 右:right 中:center 顶:top 底:bottom
          id="biaoti";
          text='';--显示文字
          textSize='20dp';--文字大小
          textIsSelectable=false;--长按复制
          layout_weight=1;
          singleLine=true;
        };
        {
          TextView;--按钮控件
          text='';--显示文字
          textSize='16dp';--文字大小
          textColor='0xFF000000';--文字颜色
          --backgroundColor='0xff1e8ae8';--纽扣背景颜色
          id="laiyuan";
          layout_weight=1;
          singleLine=true;
        };
        {
          TextView;--按钮控件
          text='';--显示文字
          textSize='16dp';--文字大小
          textColor='0xff1e8ae8';--文字颜色
          -- backgroundColor='0xff1e8ae8';--纽扣背景颜色
          id="zhuangtai";
          singleLine=true;
          -- radius='8dp';--圆角
        };
        {
          TextView;--按钮控件
          text='';--显示文字
          textSize='0dp';--文字大小
          id="lianjie";
          layout_width="0px";--布局宽度
          layout_height="0px";--布局高度
          -- radius='8dp';--圆角
        };
        {
          TextView;--按钮控件
          text='';--显示文字
          textSize='0dp';--文字大小
          id="srcurl";
          layout_width="0px";--布局宽度
          layout_height="0px";--布局高度
          -- radius='8dp';--圆角
        };
      };

    };
  };

}
tagname= {
  LinearLayout,--线性布局
  orientation="vertical";--布局方向
  layout_width="fill";--布局宽度
  layout_height="wrap";--布局高度


  {
    TextView;--水平分割线
    layout_width="fill";--布局宽度
    layout_height="1px";--布局高度
    backgroundColor="#bebebe"
  };
  {
    TextView,--水平分割线
    layout_width="fill";--布局宽度
    layout_height="100px";--布局高度
    gravity="center|center";

    singleLine=true;
    id="tagid";
    textSize="16dp";
  };

};
tagnamelist={}
nowsite=nil
function searchsite(num)
  seachitemlist={}
  nowsite=jsondata[num]
  adpsearch=LuaAdapter(activity,searchitemlist,searchitem)
  searchlist.setAdapter(adpsearch)

  datalist={}
  dataitem={}
  if jsondata[num]["id"]=="XT" then
    Http.get(string.gsub(jsondata[num]["search_href"],"searchKey",searchtext.Text),nil,"utf8",nil,function(a,b)
      if a==200 then
        bodyrange=b:match(jsondata[num]["search_range"])
        rangelists=bodyrange:gmatch(jsondata[num]["search_list"])
        for v in rangelists do
          title=v:match(jsondata[num]["search_list_name"])
          picurl=v:match(jsondata[num]["search_list_src"])
          state=v:match(jsondata[num]["search_list_state"])
          hrefurl=v:match(jsondata[num]["search_list_href"])

          adpsearch.add({
            biaoti=title,
            tupian=picurl,
            zhuangtai=state,
            laiyuan=jsondata[num]["name"],
            lianjie=jsondata[num]["search_url"]..hrefurl,
            srcurl=picurl

          })
        end
        --hreflists=bodyrange:gmatch(jsondata[num]["search_list_href"])
        -- srclists=bodyrange:gmatch(jsondata[num]["search_list_src"])
        -- statelists=bodyrange:gmatch(jsondata[num]["search_list_name"])

        --Toast.makeText(activity, tostring(rangelists),Toast.LENGTH_SHORT).show()


      end


    end)
  end
end
function settag(num)

  adptags=LuaAdapter(activity,tagnamelist,tagname)
  taglist.setAdapter(adptags)

  for k,v in pairs(jsondata) do
    --将数据逐个取出，累加进字符串进行显示
    if k==num then

      adptags.add({

        tagid={
          Text=v.name,
          backgroundColor=0xFF008AFF,
          textColor=0xFFFFFFFF
        }
      })
     else
      adptags.add({
        tagid={
          Text=v.name,
          backgroundColor=0x00FFFFFF,
          textColor=0xFF000000
        }
      })
    end
  end
end
function updatetag(num)
  for k,v in pairs(tagnamelist)
    --点击列表改变背景颜色。
    if k==num then
      searchsite(k)
      v.tagid.textColor=0xFFFFFFFF
      v.tagid.backgroundColor=0xFF008AFF
     else
      v.tagid.textColor=0xFF000000
      v.tagid.backgroundColor=0x00FFFFFF
    end

  end
  adptags.notifyDataSetChanged()--更新列表
end
settag(1)
searchsite(1)
taglist.onItemClick=function(parent, v, pos,p)

  updatetag(p)

end


searchtext.setOnEditorActionListener{
  onEditorAction=function(a,b)
    if b==3 then
      if a.Text=="" then
        return
       else
        searchword=searchtext.Text
        updatetag(1)
      end
    end
  end}
navsearch.onClick=function()
  if searchtext.Text~="" then
    --activity.newActivity("search",{searchword})
    searchword=searchtext.Text
    updatetag(1)
  end
end

searchlist.onItemClick=function(parent, v, pos,p)

  activity.newActivity("play",{v.Tag.lianjie.Text,v.tag.biaoti.Text,v.Tag.srcurl.Text,v.Tag.zhuangtai.Text,v.Tag.laiyuan.Text,nowsite})
end

