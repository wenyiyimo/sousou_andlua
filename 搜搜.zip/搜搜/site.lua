require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "siteout"
import "cjson"
import"java.io.File"

activity.setContentView(loadlayout(siteout))

--3edittext.setVisibility(View.VISIBLE)
imptext=""
sitecard={
  LinearLayout;
  orientation='vertical';--重力属性
  layout_width='fill';
  {
    CardView;--卡片控件
    layout_margin='5dp';
    layout_gravity='center';--重力
    --左:left 右:right 中:center 顶:top 底:bottom
    elevation='5dp';--阴影
    layout_width='fill';--宽度
    layout_height='wrap';--高度
    CardBackgroundColor='#ffffffff';--颜色
    radius='8dp';--圆角
    {
      TextView;
      id="sitename";
      padding="5dp";
      text='';
      textSize="16sp";
      layout_height="match_parent";

      layout_width="wrap_content";
    };

    {
      TextView;
      layout_gravity='right';--重力
      padding="5dp";
      text='';
      id="sitestate";
      textSize="16sp";
      layout_height="match_parent";
      layout_weight='1';--重力
      layout_width="wrap_content";
    };
  }
}

jsondata = cjson.decode(io.open("sdcard/搜搜/site.json"):read("*a"))

function setsite()

  adpsites=LuaAdapter(activity,{},sitecard)
  sitelist.setAdapter(adpsites)

  for k,v in pairs(jsondata) do
    --将数据逐个取出，累加进字符串进行显示
    if v.isActive then

      adpsites.add({
        sitename=v.name,
        sitestate="已启用"
      })
     else
      adpsites.add({
        sitename=v.name,
        sitestate="待启用"
      })
    end
  end
end

setsite()
goback.onClick=function()
  activity.finish()
end


sitelist.onItemLongClick=function(parent, v, pos,id)

  local temp=table.remove(jsondata,id)
  table.insert(jsondata,1,temp)

  adpsites.remove(pos)
  --将数据逐个取出，累加进字符串进行显示
  if jsondata[1].isActive then

    adpsites.insert(0,{sitename=jsondata[1].name,
      sitestate="已启用"})

   else
    adpsites.insert(0,{sitename=jsondata[1].name,
      sitestate="待启用"})

  end
  io.open("sdcard/搜搜/site.json","w"):write(cjson.encode(jsondata)):close()
  return
end

sitelist.onItemClick=function(parent, v, pos,id)
  --事件
  adpsites.remove(pos)
  if jsondata[id].isActive then
    jsondata[id].isActive=false
    adpsites.insert(pos,{sitename=jsondata[id].name,
      sitestate="待启用"})
   else
    jsondata[id].isActive=true
    adpsites.insert(pos,{sitename=jsondata[id].name,
      sitestate="已启用"})
  end
  io.open("sdcard/搜搜/site.json","w"):write(cjson.encode(jsondata)):close()
  return
end
edittext.addTextChangedListener{
  onTextChanged=function(v)
    imptext=tostring(v)

  end
}
function judgelist(jsondata,key)
  for k,v in pairs(jsondata) do
    if key==v.name then
      return false
    end
  end
  return true
end
impsite.onClick=function()
  if imptext=="" then

    --自定义位置Toast
    Toast.makeText(activity,"未输入内容!", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()



   elseif (string.sub(imptext,1,4)=="http")then
    Http.get(imptext,nil,"utf8",nil,function(a,b)
      if a==200 then
        test.Text=b
        local temp= cjson.decode(b)
        for k,v in pairs(temp) do
          if (judgelist(jsondata,v.name)) then
            table.insert(jsondata,1,v)
            if v.isActive then
              adpsites.add({
                sitename=v.name,
                sitestate="已启用"
              })
             else
              adpsites.add({
                sitename=v.name,
                sitestate="待启用"
              })
            end
          end
        end
        io.open("sdcard/搜搜/site.json","w"):write(cjson.encode(jsondata)):close()
      end
    end)
   elseif (string.sub(imptext,1,1)=="{") and (string.sub(imptext,-1,-1)=="}") then
    local temp= cjson.decode(imptext)
    if (judgelist(jsondata,temp.name)) then
      table.insert(jsondata,1,temp)
      if temp.isActive then
        adpsites.add({
          sitename=temp.name,
          sitestate="已启用"
        })
       else
        adpsites.add({
          sitename=temp.name,
          sitestate="待启用"
        })
      end
      io.open("sdcard/搜搜/site.json","w"):write(cjson.encode(jsondata)):close()
      Toast.makeText(activity,"导入完成!", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
     else
      Toast.makeText(activity,"站源名称已存在，导入失败!", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

    end
   elseif (string.sub(imptext,1,1)=="[") and (string.sub(imptext,-1,-1)=="]") then
    local temp= cjson.decode(imptext)
    for k,v in pairs(temp) do
      if (judgelist(jsondata,v.name)) then
        table.insert(jsondata,1,v)
        if v.isActive then
          adpsites.add({
            sitename=v.name,
            sitestate="已启用"
          })
         else
          adpsites.add({
            sitename=v.name,
            sitestate="待启用"
          })
        end
      end
    end
    io.open("sdcard/搜搜/site.json","w"):write(cjson.encode(jsondata)):close()
    Toast.makeText(activity,"导入完成!", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
   else

    Toast.makeText(activity,"请检查输入格式!", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

  end
end

