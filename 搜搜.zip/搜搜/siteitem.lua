require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "siteitemout"
import"java.io.File"
import "cjson"
import "common"


activity.setContentView(loadlayout(siteitemout))
function savesite()
  jsondata.name=sitenametext.Text
  jsondata.search_href=searchtext.Text
  jsondata["id"]=siteidtext.Text
  jsondata["search_range"]=searchrangetext.Text
  jsondata["search_list"]=searchitemtext.Text
  jsondata["search_list_name"]=searchtitletext.Text
  jsondata["search_list_href"]=searchhreftext.Text
  jsondata["search_url"]=searchurltext.Text
  jsondata["search_list_src"]=searchsrctext.Text
  jsondata["pic_url"]=picurltext.Text
  jsondata["search_list_state"]=searchstatetext.Text
  jsondata["play_tag_range"]=playtagrangetext.Text
  jsondata["play_tag_list"]=playtagitemtext.Text
  jsondata["play_tag_name"]=playtagnametext.Text
  jsondata["play_range"]=playrangetext.Text
  jsondata["play_list"]=playlisttext.Text
  jsondata["play_item"]=playitemtext.Text
  jsondata["play_name"]=playnametext.Text
  jsondata["play_href"]=playhreftext.Text
  jsondata["url"]=playurltext.Text
  io.open("sdcard/搜搜/siteitem.json","w"):write(cjson.encode(jsondata)):close()
end



local jsondata = cjson.decode(io.open("sdcard/搜搜/siteitem.json"):read("*a"))
--Toast.makeText(activity,tostring(jsondata["name"]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
sitenametext.setText(jsondata.name)
searchtext.setText(jsondata.search_href)
siteidtext.setText(jsondata["id"])
searchrangetext.setText(jsondata["search_range"])
searchitemtext.setText(jsondata["search_list"])
searchtitletext.setText(jsondata["search_list_name"])
searchhreftext.setText(jsondata["search_list_href"])
searchurltext.setText(jsondata["search_url"])
searchsrctext.setText(jsondata["search_list_src"])
picurltext.setText(jsondata["pic_url"])
searchstatetext.setText(jsondata["search_list_state"])
playtagrangetext.setText(jsondata["play_tag_range"])
playtagitemtext.setText(jsondata["play_tag_list"])
playtagnametext.setText(jsondata["play_tag_name"])
playrangetext.setText(jsondata["play_range"])
playlisttext.setText(jsondata["play_list"])
playitemtext.setText(jsondata["play_item"])
playnametext.setText(jsondata["play_name"])
playhreftext.setText(jsondata["play_href"])
playurltext.setText(jsondata["url"])





function checksite(sitejsondata,jsondata)
  savesite()

  for k,v in pairs(sitejsondata) do
    --将数据逐个取出，累加进字符串进行显示
    if v.name==jsondata.name then

      sitejsondata[k]=jsondata
      return true

    end
  end
  table.insert(sitejsondata,jsondata)
  return true
end

goback.onClick=function()
  savesite()
  activity.finish()
end
addsite.onClick=function()

  sitejsondata = cjson.decode(io.open("sdcard/搜搜/site.json"):read("*a"))
  checksite(sitejsondata,jsondata)
  io.open("sdcard/搜搜/site.json","w"):write(cjson.encode(sitejsondata)):close()
  Toast.makeText(activity,"保存成功!", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

end

searchrange.onClick=function()

  url=string.gsub(searchtext.Text,"searchKey","爱情")

  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        activity.newActivity("test",{res})
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,tostring("源码获取失败"), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end

searchitem.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          activity.newActivity("test",{resitem})
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end


searchtitle.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(searchtitletext.Text,resitem)
          if restitle~=false then
            activity.newActivity("test",{restitle})
           else
            Toast.makeText(activity,"名字匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end

searchhref.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(searchhreftext.Text,resitem)
          if restitle~=false then
            activity.newActivity("test",{searchurltext.Text..restitle})
           else
            Toast.makeText(activity,"链接匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end


searchsrc.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(searchsrctext.Text,resitem)
          if restitle~=false then
            activity.newActivity("test",{picurltext.Text..restitle})
           else
            Toast.makeText(activity,"图片链接匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end

searchstate.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(searchstatetext.Text,resitem)
          if restitle~=false then
            activity.newActivity("test",{restitle})
           else
            Toast.makeText(activity,"状态匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end



playtagrange.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(searchhreftext.Text,resitem)
          if restitle~=false then
            Http.get(searchurltext.Text..restitle,nil,"utf8",nil,function(a,b)
              if a==200 then
                local res=matchonce(playtagrangetext.Text,b)
                if res~=false then
                  activity.newActivity("test",{res})
                 else
                  Toast.makeText(activity,"线路范围获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                end
               else

                Toast.makeText(activity,"剧集页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

              end
            end)


           else
            Toast.makeText(activity,"链接匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"搜索页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end

playtagitem.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(searchhreftext.Text,resitem)
          if restitle~=false then
            Http.get(searchurltext.Text..restitle,nil,"utf8",nil,function(a,b)
              if a==200 then
                local res=matchonce(playtagrangetext.Text,b)
                if res~=false then
                  local resitem=matchonce(playtagitemtext.Text,res)
                  if resitem~=false then
                    activity.newActivity("test",{resitem})
                   else
                    Toast.makeText(activity,"线路列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                  end
                 else
                  Toast.makeText(activity,"线路范围获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                end
               else
                Toast.makeText(activity,"剧集页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
              end
            end)
           else
            Toast.makeText(activity,"链接匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"搜索页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end


playtagname.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(searchhreftext.Text,resitem)
          if restitle~=false then
            Http.get(searchurltext.Text..restitle,nil,"utf8",nil,function(a,b)
              if a==200 then
                local res=matchonce(playtagrangetext.Text,b)
                if res~=false then
                  local resitem=matchonce(playtagitemtext.Text,res)
                  if resitem~=false then
                    local resname=matchonce(playtagnametext.Text,resitem)
                    if resname~=false then
                      activity.newActivity("test",{resname})
                     else
                      Toast.makeText(activity,"线路名称匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                    end
                   else
                    Toast.makeText(activity,"线路列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                  end
                 else
                  Toast.makeText(activity,"线路范围获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                end
               else
                Toast.makeText(activity,"剧集页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
              end
            end)
           else
            Toast.makeText(activity,"链接匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"搜索页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end



playrange.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(searchhreftext.Text,resitem)
          if restitle~=false then
            Http.get(searchurltext.Text..restitle,nil,"utf8",nil,function(a,b)
              if a==200 then
                local res=matchonce(playrangetext.Text,b)
                if res~=false then
                  activity.newActivity("test",{res})
                 else
                  Toast.makeText(activity,"剧集范围获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                end
               else
                Toast.makeText(activity,"剧集页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
              end
            end)
           else
            Toast.makeText(activity,"链接匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"搜索页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end


playlist.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(searchhreftext.Text,resitem)
          if restitle~=false then
            Http.get(searchurltext.Text..restitle,nil,"utf8",nil,function(a,b)
              if a==200 then
                local res=matchonce(playrangetext.Text,b)
                if res~=false then
                  local resitem=matchonce(playlisttext.Text,res)
                  if resitem~=false then
                    activity.newActivity("test",{resitem})
                   else
                    Toast.makeText(activity,"剧集列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                  end
                 else
                  Toast.makeText(activity,"剧集范围获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                end
               else
                Toast.makeText(activity,"剧集页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
              end
            end)
           else
            Toast.makeText(activity,"链接匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"搜索页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end


playitem.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(searchhreftext.Text,resitem)
          if restitle~=false then
            Http.get(searchurltext.Text..restitle,nil,"utf8",nil,function(a,b)
              if a==200 then
                local res=matchonce(playrangetext.Text,b)
                if res~=false then
                  local resitem=matchonce(playlisttext.Text,res)
                  if resitem~=false then
                    local resli=matchonce(playitemtext.Text,resitem)
                    if resli~=false then
                      activity.newActivity("test",{resli})
                     else
                      Toast.makeText(activity,"每集列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                    end
                   else
                    Toast.makeText(activity,"剧集列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                  end
                 else
                  Toast.makeText(activity,"剧集范围获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                end
               else
                Toast.makeText(activity,"剧集页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
              end
            end)
           else
            Toast.makeText(activity,"链接匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"搜索页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end


playname.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(searchhreftext.Text,resitem)
          if restitle~=false then
            Http.get(searchurltext.Text..restitle,nil,"utf8",nil,function(a,b)
              if a==200 then
                local res=matchonce(playrangetext.Text,b)
                if res~=false then
                  local resitem=matchonce(playlisttext.Text,res)
                  if resitem~=false then
                    local resli=matchonce(playitemtext.Text,resitem)
                    if resli~=false then
                      local resname=matchonce(playnametext.Text,resli)

                      if resname~=false then
                        activity.newActivity("test",{resname})
                       else
                        Toast.makeText(activity,"每集名称匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                      end

                     else
                      Toast.makeText(activity,"每集列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                    end
                   else
                    Toast.makeText(activity,"剧集列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                  end
                 else
                  Toast.makeText(activity,"剧集范围获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                end
               else
                Toast.makeText(activity,"剧集页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
              end
            end)
           else
            Toast.makeText(activity,"链接匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"搜索页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end


playhref.onClick=function()
  url=string.gsub(searchtext.Text,"searchKey","爱情")
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(searchrangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(searchitemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(searchhreftext.Text,resitem)
          if restitle~=false then
            Http.get(searchurltext.Text..restitle,nil,"utf8",nil,function(a,b)
              if a==200 then
                local res=matchonce(playrangetext.Text,b)
                if res~=false then
                  local resitem=matchonce(playlisttext.Text,res)
                  if resitem~=false then
                    local resli=matchonce(playitemtext.Text,resitem)
                    if resli~=false then
                      local resname=matchonce(playhreftext.Text,resli)

                      if resname~=false then
                        activity.newActivity("test",{playurltext.Text..resname})
                       else
                        Toast.makeText(activity,"每集链接匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                      end

                     else
                      Toast.makeText(activity,"每集列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                    end
                   else
                    Toast.makeText(activity,"剧集列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                  end
                 else
                  Toast.makeText(activity,"剧集范围获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
                end
               else
                Toast.makeText(activity,"剧集页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
              end
            end)
           else
            Toast.makeText(activity,"链接匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"搜索页源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end


sitenametext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
searchtext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
siteidtext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
searchrangetext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
searchitemtext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
searchtitletext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
searchhreftext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
searchurltext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
searchsrctext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
picurltext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
searchstatetext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
playtagrangetext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
playtagitemtext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
playtagnametext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
playrangetext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
playlisttext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
playitemtext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
playnametext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
playhreftext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
playurltext.addTextChangedListener{
  onTextChanged=function(a)
    savesite()
  end,
}
