function initdata()
  if File("sdcard/搜搜/siteitem.json").exists() then
    --文件存在事件
   else File("/sdcard/搜搜").mkdir()--不存在 则创建
    io.open("sdcard/搜搜/siteitem.json","w"):write([[{
	"name": "骚火",
    "id": "XT",
	"url": "https://saohuo.vip",
	"search_url": "https://saohuo.vip",
	"pic_url": "",
	"search_href": "https://saohuo.vip/search.php?searchword=searchKey",
	"search_range": "v_list([%s%S]-)</ul>",
	"search_list": "v_img([%s%S]-)v_title",
	"search_list_name": "title=\"([%s%S]-)\"",
	"search_list_href": "href=\"([%s%S]-)\"",
	"search_list_src": "original=\"([%s%S]-)\"",
	"search_list_state": "v_note\">([%s%S]-)</div>",
	"play_tag_range": "播放源([%s%S]-)</ul>",
	"play_tag_list": "<li([%s%S]-)li>",
	"play_tag_name": ">([%s%S]-)<",
	"play_range": "id=\"play_link\"([%s%S]-)</ul>",
	"play_list": "<li([%s%S]-)</li>",
	"play_item": "<a([%s%S]-)</a>",
	"play_name": "title=\"([%s%S]-)\"",
	"play_href": "href=\"([%s%S]-)\"",
    "exceptstring":"",
	"isActive":true
}]]):close()
  end
  if File("sdcard/搜搜/site.json").exists() then
    --文件存在事件
   else File("/sdcard/搜搜").mkdir()--不存在 则创建
    io.open("sdcard/搜搜/site.json","w"):write("[]"):close()
  end
  if File("sdcard/搜搜/index.json").exists() then
    --文件存在事件
   else File("/sdcard/搜搜").mkdir()--不存在 则创建
    io.open("sdcard/搜搜/index.json","w"):write([[{
	"texttype": "HTML",
	"tagname": "追剧&&&电影&&&动漫&&&综艺",
    "tagurl": "",
	"startnum": "1",
	"secondnum": "2",
	"range": "",
	"item": "",
	"picture": "",
	"picurl": "",
	"title": "",
	"state":""
}]]):close()
  end
end
function matchonce(key,html)
  local result=html:match(key)
  if result==nil then
    return false
   else
    return result
  end
end
function split(input, delimiter)
  input = tostring(input)
  delimiter = tostring(delimiter)
  if (delimiter == "") then return false end
  local pos, arr = 0, {}
  for st, sp in function() return string.find(input, delimiter, pos, true) end do
    table.insert(arr, string.sub(input, pos, st - 1))
    pos = sp + 1
  end
  table.insert(arr, string.sub(input, pos))
  return arr
end
