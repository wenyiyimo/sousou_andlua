require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "testout"


activity.setContentView(loadlayout(testout))
showtext.Text=...