require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "indexout"
import "cjson"
import "common"

activity.setContentView(loadlayout(indexout))
local jsondata = cjson.decode(io.open("sdcard/搜搜/index.json"):read("*a"))
--Toast.makeText(activity,tostring(jsondata["name"]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
texttypetext.setText(jsondata.texttype)
tagnametext.setText(jsondata.tagname)
tagurltext.setText(jsondata["tagurl"])
startnum.setText(jsondata["startnum"])
secondnum.setText(jsondata["secondnum"])
rangetext.setText(jsondata["range"])
itemtext.setText(jsondata["item"])
titletext.setText(jsondata["title"])

pictext.setText(jsondata["picture"])
picurltext.setText(jsondata["picurl"])
statetext.setText(jsondata["state"])

function saveindex()

  jsondata["texttype"]=texttypetext.Text
  jsondata["tagname"]=tagnametext.Text
  jsondata["tagurl"]=tagurltext.Text
  jsondata["startnum"]=startnum.Text
  jsondata["secondnum"]=secondnum.Text
  jsondata["range"]=rangetext.Text
  jsondata["item"]=itemtext.Text
  jsondata["title"]=titletext.Text
  jsondata["picture"]=pictext.Text
  jsondata["picurl"]=picurltext.Text
  jsondata["state"]=statetext.Text

  io.open("sdcard/搜搜/index.json","w"):write(cjson.encode(jsondata)):close()
end


tagname.onClick=function()
  local res=split(tagnametext.Text,"&&&")
  --Toast.makeText(activity,tostring(res[1]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
  activity.newActivity("test",{tostring(res[1])})

end


tagurl.onClick=function()
  local res=split(tagurltext.Text,"&&&")
  local url= string.gsub(res[1],"PAGE",startnum.Text)
  --Toast.makeText(activity,tostring(res[1]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
  activity.newActivity("test",{tostring(url)})
end
range.onClick=function()
  local res=split(tagurltext.Text,"&&&")
  local url= string.gsub(res[1],"PAGE",startnum.Text)
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local resrange=matchonce(rangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if resrange~=false then
        activity.newActivity("test",{resrange})
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,tostring("源码获取失败"), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end

item.onClick=function()
  local resurl=split(tagurltext.Text,"&&&")
  local url= string.gsub(resurl[1],"PAGE",startnum.Text)
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(rangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(itemtext.Text,res)
        if resitem~=false then
          activity.newActivity("test",{resitem})
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end
title.onClick=function()
  local resurl=split(tagurltext.Text,"&&&")
  local url= string.gsub(resurl[1],"PAGE",startnum.Text)
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(rangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(itemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(titletext.Text,resitem)
          if restitle~=false then
            activity.newActivity("test",{restitle})
           else
            Toast.makeText(activity,"名字匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end

picture.onClick=function()
  local resurl=split(tagurltext.Text,"&&&")
  local url= string.gsub(resurl[1],"PAGE",startnum.Text)
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(rangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(itemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(pictext.Text,resitem)
          if restitle~=false then
            activity.newActivity("test",{picurltext.Text..restitle})
           else
            Toast.makeText(activity,"图片链接匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end

state.onClick=function()
  local resurl=split(tagurltext.Text,"&&&")
  local url= string.gsub(resurl[1],"PAGE",startnum.Text)
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      local res=matchonce(rangetext.Text,b)
      --Toast.makeText(activity,tostring(res[0]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      if res~=false then
        local resitem=matchonce(itemtext.Text,res)
        if resitem~=false then
          local restitle=matchonce(statetext.Text,resitem)
          if restitle~=false then
            activity.newActivity("test",{restitle})
           else
            Toast.makeText(activity,"状态匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

          end
         else
          Toast.makeText(activity,"列表匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()

        end
       else
        Toast.makeText(activity,"范围匹配失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
      end
     else
      Toast.makeText(activity,"源码获取失败", Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
    end
  end)
end



texttypetext.addTextChangedListener{
  onTextChanged=function(a)
    saveindex()
  end,
}
tagnametext.addTextChangedListener{
  onTextChanged=function(a)
    saveindex()
  end,
}
tagurltext.addTextChangedListener{
  onTextChanged=function(a)
    saveindex()
  end,
}
startnum.addTextChangedListener{
  onTextChanged=function(a)
    saveindex()
  end,
}
secondnum.addTextChangedListener{
  onTextChanged=function(a)
    saveindex()
  end,
}
rangetext.addTextChangedListener{
  onTextChanged=function(a)
    saveindex()
  end,
}
itemtext.addTextChangedListener{
  onTextChanged=function(a)
    saveindex()
  end,
}
titletext.addTextChangedListener{
  onTextChanged=function(a)
    saveindex()
  end,
}

pictext.addTextChangedListener{
  onTextChanged=function(a)
    saveindex()
  end,
}
picurltext.addTextChangedListener{
  onTextChanged=function(a)
    saveindex()
  end,
}
statetext.addTextChangedListener{
  onTextChanged=function(a)
    saveindex()
  end,
}