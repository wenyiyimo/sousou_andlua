require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
import"java.io.File"
import "common"
import "cjson"
activity.setContentView(loadlayout(layout))
initdata()
local jsondata = cjson.decode(io.open("sdcard/搜搜/index.json"):read("*a"))
local tagnames=split(jsondata.tagname,"&&&")
local tagurls=split(jsondata.tagurl,"&&&")
local pagenum=1
local tagnum=1
local items={}
time={
  LinearLayout;
  layout_height="wrap";
  background="#00FFFFFF";
  layout_width="fill";
  orientation="vertical";
  {
    CardView;--卡片控件
    layout_marginLeft='5dp';--边距
    layout_marginRight='5dp';
    layout_gravity='center';--重力
    --左:left 右:right 中:center 顶:top 底:bottom
    elevation='5dp';--阴影
    layout_width='fill';--宽度
    layout_height='wrap';--高度
    CardBackgroundColor='#ffffffff';--颜色
    radius='8dp';--圆角
    {
      FrameLayout,--帧布局
      --orientation='vertical',--方向
      layout_width='fill',--宽度
      layout_height='40%w',--高度
      background='#00FFFFFF',--背景颜色或图片路径
      {
        ImageView;--图片控件
        src='';--图片路径
        layout_width='fill';--宽度
        layout_height='fill';--高度
        scaleType='fitXY';--图片显示类型
        id="tupian"
      };
      {
        TextView;--按钮控件
        text='';--显示文字
        textSize='14dp';--文字大小
        textColor='0xFFFFFFFF';--文字颜色
        backgroundColor='0xff1e8ae8';--纽扣背景颜色
        id="zhuangtai";
        singleLine=true;
      };
    };
  };
  {
    LinearLayout,--线性布局
    orientation='vertical',--方向
    layout_width='fill',--宽度
    layout_height='wrap',--高度
    background='#00FFFFFF',--背景颜色或图片路径
    {
      TextView;--文本控件
      --左:left 右:right 中:center 顶:top 底:bottom
      id="biaoti";
      text='';--显示文字
      textSize='16dp';--文字大小
      textIsSelectable=false;--长按复制
      layout_marginLeft="5dp";
      singleLine=true;
    };
  };
}


adpp=LuaAdapter(activity,time)
list.setAdapter(adpp)
list.onItemClick=function(parent, v, pos,id)
  print(v.Tag.biaoti.Text)
  activity.newActivity("search",{v.Tag.biaoti.Text})
end

--Toast.makeText(activity,tostring(tagurls[1]), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
function getawidth()
  if (activity.getWidth()/#tagnames) <70 then
    return "70dp"
   else
    return activity.getWidth()/#tagnames

  end
end
function geturl()

  if pagenum==1 then
    return string.gsub(tagurls[tagnum],"PAGE",tostring(jsondata["startnum"]))
   elseif pagenum==2 then
    pagenum=tointeger(jsondata["secondnum"])

    return string.gsub(tagurls[tagnum],"PAGE",tostring(pagenum))
   else
    return string.gsub(tagurls[tagnum],"PAGE",tostring(pagenum))
  end
end

function getbody()
  local url=geturl()
  Http.get(url,nil,"utf8",nil,function(a,b)
    if a==200 then
      bodyrange=b:match(jsondata["range"])
      alllists=bodyrange:gmatch(jsondata["item"])
      --bodytext.text=bodyrange
      for v in alllists do
        title=v:match(jsondata["title"])
        picurl=jsondata["picurl"]..(v:match(jsondata["picture"]))
        state=v:match(jsondata["state"])

        adpp.add({
          biaoti=title,
          tupian=picurl,
          zhuangtai=state
        })
      end
    end


  end)
end

getbody()
function settagout(num,tagcolor,tagname)
  return

  {
    TextView;
    text=tagname;
    textSize="20dp";
    layout_width=getawidth();
    layout_height="match_parent";
    gravity="center|center";
    id="button"..tostring(num);
    textColor=tagcolor;
    onClick=function(v)

      v.textColor=0xFF008AFF
      (activity.getWindow().findViewById(v.id-num+tagnum)).setTextColor(0xFF000000)
      tagnum=num
      pagenum=1
      adpp=LuaAdapter(activity,time)
      list.setAdapter(adpp)
      getbody()
    end
  }
end

for i,tagname in ipairs(tagnames) do

  --Toast.makeText(activity,tostring(tagname), Toast.LENGTH_LONG).setGravity(Gravity.TOP, 0, 200).show()
  if i==tagnum then
    ctag.addView(loadlayout(settagout(i,0xFF008AFF,tagname)))
   else
    ctag.addView(loadlayout(settagout(i,0xFF000000,tagname)))
  end
end





shuaxin.onLoadMore=function(v)
  pagenum=pagenum+1
  getbody()
  v.loadmoreFinish(0)
end


navsite.onClick=function()--点击事件

  activity.newActivity("setting")
end;




searchword=""
searchtext.setOnEditorActionListener{
  onEditorAction=function(a,b)
    if b==3 then
      if a.Text=="" then
        return
       else
        activity.newActivity("search",{searchtext.Text})
      end
    end
  end}


navsearch.onClick=function()
  if searchtext.Text~="" then
    --activity.newActivity("search",{searchword})
    activity.newActivity("search",{searchtext.Text})
  end
end




