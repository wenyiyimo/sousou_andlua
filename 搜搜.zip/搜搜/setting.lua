require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "setout"


activity.setContentView(loadlayout(setout))

sitemanager.onClick=function()

  activity.newActivity("site")
  --activity.newActivity("search",{searchtext.Text})

end
addsite.onClick=function()
  activity.newActivity("siteitem")
  --activity.newActivity("search",{searchtext.Text})
end


goback.onClick=function()
  activity.finish()
end


addindex.onClick=function()
  activity.newActivity("index")
  --activity.newActivity("search",{searchtext.Text})
end

